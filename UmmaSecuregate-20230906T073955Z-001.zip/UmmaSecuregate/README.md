Security Staff Management and Incident Recording System.
![Screenshot (56)](https://github.com/itsfidelgray/anothertest/assets/63525545/1fceedf0-c0c1-4cc6-a83a-8897ccb59481)

![Screenshot (43)](https://github.com/itsfidelgray/anothertest/assets/63525545/170f29f4-ce9f-47fd-b8c5-c90322cb7ef3)
![Screenshot (44)](https://github.com/itsfidelgray/anothertest/assets/63525545/b46b8d11-d95e-4e7b-a449-4636b325281f)

![Screenshot (57)](https://github.com/itsfidelgray/anothertest/assets/63525545/a413401b-ebfa-40e2-ab5c-5e3cbd5482f4)

![Screenshot (46)](https://github.com/itsfidelgray/anothertest/assets/63525545/7829c84e-abb7-4fd8-b0e3-b22ddc0eab51)


![Screenshot (47)](https://github.com/itsfidelgray/anothertest/assets/63525545/c8842e0e-6291-4c54-9d88-cef9d11d77c7)
![Screenshot (49)](https://github.com/itsfidelgray/anothertest/assets/63525545/20c664d9-4dbb-4337-87ba-843d25f92951)
![Screenshot (50)](https://github.com/itsfidelgray/anothertest/assets/63525545/1027f3fc-b9bc-4021-b81f-be82f9200fed)

![Screenshot (51)](https://github.com/itsfidelgray/anothertest/assets/63525545/6a3db2e7-6c46-4d2f-9ac8-869c65902c02)
![Screenshot (52)](https://github.com/itsfidelgray/anothertest/assets/63525545/48015fac-423f-4c97-9a6b-901d0b307eeb)

![Screenshot (53)](https://github.com/itsfidelgray/anothertest/assets/63525545/ef1e1cd5-8988-4119-89a5-03f4ad0a1920)
![Screenshot (54)](https://github.com/itsfidelgray/anothertest/assets/63525545/4e223a43-4a26-4aaf-979f-586533d3bda8)
![Screenshot (55)](https://github.com/itsfidelgray/anothertest/assets/63525545/441fbf6c-edff-43fc-89ec-e0ad14b9e402)
