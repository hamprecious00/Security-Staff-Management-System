import React from 'react'

const AccessLogs = () => {
  return (
    <div>AccessLogs</div>
  )
}

export default AccessLogs